fomo campus brand kit
Edition 04 · October 2026
Live version: https://bijanizadian.com/campus/brandkit


START HERE

Read fomo-campus-brand-kit.pdf. Its first sheet, "fomo brand kit", is
fomo's own rules: they come first, and every campus rule builds on
them without overriding them.


WHAT'S IN THIS FOLDER

01-fomo-marks           The fomo eyes mark and wordmark, named by color
                        (pale, ink, blue), unchanged from fomo's kit.

02-campus-logo          The fomo campus graduation-cap mark in white,
                        purple, and ink. SVG + transparent PNG.

03-social-templates     The basic grid post (1080 × 1350) and story
                        (1080 × 1920) in the four campus colorways.

04-campaign-templates   Six patterns, each in four colorways, as grid
                        and story:
                          01 heating-up-chapters   02 top-chapters
                          03 fastest-onboards      04 growth-milestone
                          05 chapter-milestone     06 chapter-invite

05-tokens               Color and type values as CSS and JSON.

06-extras               The carousel teaching slide, and the hand-drawn
                        call-to-action arrow in white and ink. The arrow
                        sits just left of dm "fomo" to get the link and
                        sweeps down-left toward the story reply box.


THE FOUR COLORWAYS

purple     campus purple (fomo blue #516AF6), white type
lavender   pale lavender #EAEDFF, ink type
ink        fomo ink #0B091F, white type, light blue highlight
white      white, ink type, campus purple display type


BEFORE YOU POST

- Edit the SVGs; the PNGs are previews of the same layouts.
- Replace every [bracketed] placeholder. Use only confirmed counts,
  times, and offers.
- Use approved school and chapter logos, in their own colors.
- Keep "fomo" lowercase.
- End with dm "fomo" to get the link at the bottom right, with the
  hand-drawn arrow. No straight arrows.
- Aeonik is fomo's licensed typeface and isn't included. Without it the
  SVGs fall back to Arial; the PNGs show the intended type.
