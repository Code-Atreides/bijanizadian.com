pump.fun campus brand kit, Edition 02 (November 2026)
https://bijanizadian.com/pumpfunbrandkit

pump.fun's portal rules come first; the campus layer builds on them.

mark/       capsule (transparent PNG, from pump.fun's reference) and the campaign tile
social/     grid 1080x1350 and story 1080x1920 templates, SVG + PNG,
            in campaign green (-green) and ink (-ink). Standings is ink only.
media/      Reels/TikTok layers, 1080x1920: safe-zone guide, tag overlay, end card.
            Caption area: 72 px left, 180 px right, 270 px top, 480 px bottom.
fonts/      Geist Sans Regular 400 and Semibold 600, SIL Open Font License.
web/        portal components CSS (scoped under .pf-portal) and design tokens JSON.

Replace every [bracket] with confirmed names, dates and counts.
No token prices, wallets, balances or financial advice in campus content.
Campus layouts, copy and placement rules are proposed applications.
